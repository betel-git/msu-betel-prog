#include <stdio.h>
#include <math.h>

double Lastnumber (FILE *f, double epsilon, double x);