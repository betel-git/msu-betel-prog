#include <stddef.h>
#include <stdio.h>

double * ReadArrayCnt(FILE *f, size_t *size, int *errcode);
