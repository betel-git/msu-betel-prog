#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int Len(FILE *f);
void Scan(FILE *f, double *a, int n);
void Func(double *a, int n, double m);
double Mediana(double *a, int n);