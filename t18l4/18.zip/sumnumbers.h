#include <stdio.h>
#include <math.h>

double SumNumbers (FILE *f);