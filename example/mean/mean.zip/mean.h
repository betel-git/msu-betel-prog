#include <stdio.h>

double CalculateMeanValue (FILE *f);
