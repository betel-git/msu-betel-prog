#include <stdio.h>
#include <math.h>

double GreatestSequence (FILE *f);