// 
//  пример простейшего кода для обработки последовательности
// 
#ifndef MINMAX_H      // об этом речь будет потом
#define MINMAX_H

// прототипы наших функций

int find_max_segment(int *arr, int size);

#endif // MINMAX_H
